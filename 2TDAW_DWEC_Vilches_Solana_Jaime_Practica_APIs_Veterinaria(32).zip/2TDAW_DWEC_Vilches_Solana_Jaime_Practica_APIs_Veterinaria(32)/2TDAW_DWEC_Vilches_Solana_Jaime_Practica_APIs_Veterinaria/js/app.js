"use strict"
//EXTERNA

const gal = document.querySelector("#fotos");

if(gal !==null){

  galeriaCompleta("https://dog.ceo/api/breeds/image/random/6");

  const crear = (imagen) => {

    const ima = document.createElement("img");
    const cont = document.createElement("div");
    ima.src = imagen;
    ima.classList.add("w-75","shadow-1-strong","mb-4","img-fluid","rounded-circle");
    ima.style.height="275px";
    cont.classList.add("col-5","col-md-4");

    cont.appendChild(ima);

    return cont;
  }


  async function galeriaCompleta(url) {
    const respuesta = await fetch(url);
    const datos = await respuesta.json();
    const lista_perros = datos["message"];

    lista_perros.forEach(
      (perro) => {
        gal.appendChild(crear(perro));
      });
  }
}

//INTERNA
const tabla_noticias = document.querySelector("#lista_noticias");




  const nuevaNoticia = (json) => {
    let art=document.createElement("article");
    art.classList.add("noticia");
    art.id = "ID_" + json["titulo"].toUpperCase().replaceAll(" ", "");
  
    let imagen = document.createElement("img");
    let td_imagen = document.createElement("div");
    let td_titulo = document.createElement("h3");
    let td_contenido = document.createElement("p");
    imagen.classList.add("w-25","shadow-1-strong","mb-4","img-fluid","rounded-circle");
    imagen.style.height="300px";
    imagen.src=json["imagen"];
    td_imagen.classList.add("d-flex","justify-content-center");

    td_imagen.appendChild(imagen);
    art.appendChild(td_imagen);
  
    td_titulo.classList.add("text-primary","bg-dark");
    art.appendChild(td_titulo);
    td_titulo.innerText = json["titulo"];

    td_contenido.classList.add("text-warning","bg-dark","d-flex","justify-content-center");


    const textoC=json["contenido"];

    let textoAreaDividido = textoC.split(" ");
    let numeroPalabras = textoAreaDividido.length;

    if(numeroPalabras>200){
      for (let i = 0; i < 200; i++) {
        td_contenido.innerText += textoAreaDividido[i]+" ";
    }
      td_contenido.innerText += "...";
    }else{
      td_contenido.innerText = textoC;
    }
  
  
    art.appendChild(td_contenido);

    let lineas=document.createElement("hr");
  
    return art;
  }

if(tabla_noticias!==null){
  if (sessionStorage.length === 0) {

    (async () => {
      const respuesta = await fetch("noticiaTabla.php");
      const datos_noticias = await respuesta.json();

      datos_noticias.forEach((noticia) => {
        sessionStorage.setItem("ID_" + noticia["titulo"].
          toUpperCase()
          .replaceAll(" ", ""),
          JSON.stringify(noticia))
      });
      Object.values(sessionStorage).forEach(
        (noticia) => {
          tabla_noticias.appendChild(nuevaNoticia(JSON.parse(noticia)));
        }
      )
    })();
    
  } else {
    Object.values(sessionStorage).forEach(
      (noticia) => {
        tabla_noticias.appendChild(nuevaNoticia(JSON.parse(noticia)));
      }
    )
  }
}