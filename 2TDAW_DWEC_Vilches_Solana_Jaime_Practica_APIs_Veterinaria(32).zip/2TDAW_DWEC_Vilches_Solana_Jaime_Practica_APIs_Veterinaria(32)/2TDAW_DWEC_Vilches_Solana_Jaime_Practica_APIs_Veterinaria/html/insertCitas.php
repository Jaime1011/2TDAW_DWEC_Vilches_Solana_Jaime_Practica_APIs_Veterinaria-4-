<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Insertar</title>
</head>
<body>
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>
    <main>
    <?php
        $con=conexionVete();
        
        echo"<form method='POST' action='#' enctype='multipart/form-data'>";
        
        $clientes_id="select nombre, id from cliente ";
        $contenido_id=$con->query($clientes_id);
        echo"<div class='opciones_insertCitas'>Cliente:  <select name='Clientes'>";
        while ($id_desplegable=$contenido_id->fetch_array(MYSQLI_ASSOC)) {
            echo" <option value=$id_desplegable[id]>$id_desplegable[nombre]</option>";
        }
        echo "</select><br>";

        $servicio_id="select descripcion, id from servicio ";
        $contenido_id_ser=$con->query($servicio_id);


        echo" Servicio: <select name='Servicios'>";
        while ($id_desplegable_ser=$contenido_id_ser->fetch_array(MYSQLI_ASSOC)) {
            echo" <option value=$id_desplegable_ser[id]>$id_desplegable_ser[descripcion]</option>";
        }
        echo "</select><br>";


        echo"<label for='fecha'>Fecha:</label>
            <input type='date' name='fecha'>
            <br>
            <label for='hora'>Hora:</label>
            <input type='time' name='hora'>
            <br>
            <input type='submit' name='insertar'>
            </form></div>";

        if (isset($_POST['insertar'])) {
            $nom_cli= $_POST['Clientes'];
            $servicio= $_POST['Servicios'];
            $fecha= $_POST['fecha'];
            $hora= $_POST['hora'];

            $crear="insert into citas values(?,?,?,?)";
            $consulta=$con->prepare($crear);
            $consulta->bind_param("iiss",$nom_cli,$servicio,$fecha,$hora);
            $consulta->execute();

            $consulta->close();
            
        }

        ?>
    </main>
    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>