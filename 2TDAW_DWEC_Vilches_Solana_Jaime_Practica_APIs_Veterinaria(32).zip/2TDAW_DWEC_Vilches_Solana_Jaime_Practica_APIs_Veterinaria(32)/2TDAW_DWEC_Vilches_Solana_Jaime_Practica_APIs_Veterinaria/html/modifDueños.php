<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        <!-- PHP RECOGER ID -->
        <?php
            $mostrarId='select AUTO_INCREMENT from information_schema.TABLES where TABLE_SCHEMA="veterinaria" and TABLE_NAME="dueño"';
            $con=conexionVete();

            $muestra = $con->query($mostrarId);

            if($muestra == true){
                $datos=$con->query($mostrarId);
                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                    if($datos->num_rows<=0){
                        echo "No se ha encontrado una Id";
                    }else{
                        while($fila = $datos->fetch_row()){
                            $IdDueño = $fila[0];
                        }
                    }
                }
            }else{
                echo "Error en la busqueda de Id";
            }
        ?>

        <h1>MODIFICAR DUEÑOS</h1>
        <div class="fondo_modificar">

        <?php
            // SELECION ID
            $con=conexionVete();
            $idDueño=$_POST['dato'];
            $consulta1="SELECT * FROM dueño WHERE dni='$idDueño'";
            $resultado=$con->query($consulta1);
            $fila=$resultado->fetch_array();
            if($resultado->num_rows>0){
                echo"<form action='#' method='post'  enctype='multipart/form-data'>
                        <label for='dni'>Dni:</label>
                        <input type='text' name='dni'>
                        <br>
                        <label for='nombre'>Nombre:</label>
                        <input type='text' name='nombre'  value='$fila[nombre]'>
                        <br>
                        <label>Teléfono:</label>
                        <input type='phone' name='telefono'  value='$fila[telefono]'>
                        <br>
                        <label for='nick'>Nick:</label>
                        <input type='text' name='nick'  value='$fila[nick]'>
                        <br>
                        <label for='pass'>Contraseña:</label>
                        <input type='password' name='pass'  value='$fila[pass]'>
                        <br>
                        <input id='boton_noticia' type='submit' name=enviar>
                        <input type='hidden' name='dato' value='$fila[dni]'>
                    </form>";
            }
        ?>

        <!-- SELECIONAR IMAGENES -->
        <?php
            if(isset($_POST["enviar"])){
                $dni=$_POST['dni'];
                $nombre=$_POST['nombre'];
                $telefono=$_POST['telefono'];
                $nick=$_POST['nick'];
                $pass=$_POST['pass'];
                

                $con=conexionVete();

                $sentencia = "UPDATE dueño
                                SET dni='$dni', nombre='$nombre', telefono='$telefono', nick='$nick', pass='$pass'";

                $resultado = $con->query($sentencia);

                if(!$resultado){
                    echo "error en la sentecia $con->error";
                }else{
                    echo "MODIFICADO CORERECTAMENTE";
                }
                $con->close();
                // echo "<meta http-equiv='refresh' content='0;url=../html/dueños.php'>";
            }
        ?>
    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>