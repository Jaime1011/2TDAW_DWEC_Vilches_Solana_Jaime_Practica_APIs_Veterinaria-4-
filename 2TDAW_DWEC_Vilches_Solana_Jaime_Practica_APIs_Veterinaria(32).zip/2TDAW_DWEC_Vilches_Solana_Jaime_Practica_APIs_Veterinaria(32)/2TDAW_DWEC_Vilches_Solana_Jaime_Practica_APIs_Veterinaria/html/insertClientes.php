<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
    <!-- PHP RECOGER ID -->
    <?php
        $mostrarId='select AUTO_INCREMENT from information_schema.TABLES where TABLE_SCHEMA="veterinaria" and TABLE_NAME="cliente"';
        $con=conexionVete();

        $muestra = $con->query($mostrarId);

        if($muestra == true){
            $datos=$con->query($mostrarId);
            if(!$datos){
                echo "error en la sentencia $con->error";
            }else{
                if($datos->num_rows<=0){
                    echo "No se ha encontrado una Id";
                }else{
                    while($fila = $datos->fetch_row()){
                        $IdCliente = $fila[0];
                    }
                }
            }
        }else{
            echo "Error en la busqueda de Id";
        }
    ?>

        <h1>INSERTAR CLIENTES</h1>
        <div class="fondo_modificar" >
            <form action="#" method="post" enctype="multipart/form-data">
                <div id='primero'>
                    Id:
                    <br>
                    <input type='text' name='id' disabled placeholder=<?php echo $IdCliente?>>
                    <br>
                    Tipo *
                    <br>
                    <input type='text' name='tipo' required>
                    <br>
                    Nombre *
                    <br>
                    <input type='text' name='nombre' required>
                </div>
                <div id='segundo'>
                    Edad *
                    <br>
                    <input type='number' name='edad' required>
                    <br>
                    Nombre del dueño *
                    <br>
                    <select name="nombre_dueño" id="duenio" required>
                        <?php
                            while ($fila_duenios=$datos->fetch_array(MYSQLI_ASSOC)){
                                echo "<option value='$fila_duenios[dni]'>$fila_duenios[nombre]</option>";
                            }
                        ?>
                    </select>
                </div>
                <div id='tercero'>
                    Contraseña 
                    <br>
                    <input type='text' name='contraseña'>
                    <br>
                    Telefono *
                    <br>
                    <input type='tel' name='telefono' required>
                </div>
                <div id='cuarto'>
                    <br>
                    Foto *
                    <br>
                    <input type='file' name='Foto' required>
                </div>
                <br>
                <input id='boton' type='submit' name=enviar>
            </form>     
        </div>
        <!-- PHP SELECIONAR IMAGENES -->
        <?php
            if(isset($_POST["enviar"])){
                $imagen_cliente=$_FILES['Foto']['name'];
                $temp=$_FILES['Foto']['tmp_name'];

                if(!file_exists("../assetsClientes/")){
                    mkdir("../assetsClientes/");
                }

                if($_FILES['Foto']['type']==="image/png"){
                    $imagen_cliente=$imagen_cliente.".png";
                }elseif($_FILES['Foto']['type']==="image/jpg"){
                    $imagen_cliente=$imagen_cliente.".jpg";
                }

                $ruta1="../assets/$imagen_cliente";
                $ruta2="assets/$imagen_cliente";

                move_uploaded_file($temp,$ruta1);

                $tipo=$_POST['tipo'];
                $nombre=$_POST['nombre'];
                $edad=$_POST['edad'];
                $nombre_dueño=$_POST['nombre_dueño'];
                $contraseña=$_POST['contraseña'];
                $telefono=$_POST['telefono'];
                

                $con=conexionVete();

                $sentencia = "insert into cliente
                                values ('','$tipo', '$nombre', '$edad', '$nombre_dueño', '$contraseña', '$telefono', '$ruta2')";

                $datos = $con->query($sentencia);

                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                    echo "datos insertados correctamente";
                }
                $con->close();
            }
        ?>

    </main>

    <footer>
        <!-- FUNCION FOOTER -->
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>