<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"]) || $_SESSION["dni"]!=="000000000"){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="../styles/styles.css">
    <script type="text/javascript" src="../js/app.js" defer></script>
    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        <div id="fondo_noticias">
            <h1>NOTICIAS</h1>
            <?php
                if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                    echo "<a id='boton_pg' href='../html/insertNoticias.php'><input style='margin-left: 47.5%;' id='insertar' type='button' value='Insertar'></a>";
                }
            ?>
            <hr id="hr1">
        </div>

        <section id="noticiasPagina">

            <div id='lista_noticias'></div>

        </section>

    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>