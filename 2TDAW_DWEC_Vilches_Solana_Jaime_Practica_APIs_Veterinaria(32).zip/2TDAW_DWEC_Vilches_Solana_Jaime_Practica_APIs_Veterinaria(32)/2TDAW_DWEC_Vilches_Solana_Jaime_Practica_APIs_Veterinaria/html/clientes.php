<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
        if($_SESSION["dni"]==="000000000"){
            echo "<title>Clientes</title>";
        }else{
            echo "<title>Mis mascotas</title>";
        }
    ?>
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>

<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        
        <div id="fondo_noticias">
        <h1>CLIENTES</h1>
        <?php
            if($_SESSION["dni"]==="000000000"){
                echo "<a id='boton_pg' href='../html/insertClientes.php'><input style='margin-left: 47.5%;' id='insertar' type='button' value='Insertar'></a>";
                
            }
        ?>

        <!-- BUSCADOR -->
        <form action='../html/buscarClientes.php' method='post' id='buscador'>
        	<input id="buscador" type="text" name="busqueda" placeholder="Buscar..." aria-label="Search">
            <input id='buscar' type='submit' name='enviar-buscar' value='Buscar'>
        </form>
        
        <!-- PHP muestra clientes -->
        <?php
                //1. conectarme con la base de datos
                $con=conexionVete();

                //2. crear la consulta
                $sentencia = "Select id,cliente.nombre nom_cli,tipo,edad,foto,dueño.nombre nom_due
						    from cliente, dueño";

                //3. ejecutar la sentencia
                $datos = $con->query($sentencia);

                //4. comprobar errores
                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                //5. comprobar si hay datos
                if($datos->num_rows<=0){
                    echo "No hay clientes para mostrar";
                }else{
                //6. trabajar con los datos
                    while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
                        echo 
                        "<div class='cliente'>
                            <hr id='hr1'>
                            <img src='../assets/$fila[foto]' style='width: 25%;'>
                            <h2>$fila[nom_cli]</h2>
                            <h3>Tipo: $fila[tipo]</h3>
                            <h3>Edad: $fila[edad] años</h3>
                            <h3>Nombre del dueño: $fila[nom_due]</h3>";

                            if($_SESSION["dni"]==="000000000"){
                                echo "<form action='../html/modifClientes.php' method='post'>
                                    <input id='modificar' type='submit' value='Modificar'>
                                    <input type='hidden' name='dato' value='$fila[id]'>
                                </form>";
                            }
                            echo "<hr> 
                            </div>";
                        }

                   
                    }
                }
            
            $con->close();
            ?>
        </div>

    </main>

    <footer>
        <!-- FUNCION FOOTER -->
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>