<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
    <!-- PHP RECOGER ID -->
        <h1>INSERTAR DUEÑOS</h1>
        <div class="fondo_modificar" >
            <form action="#" method="post" enctype="multipart/form-data">
                <div id='primero'>
                    Dni *
                    <br>
                    <input type='text' name='dni' required>
                    <br>
                    Nombre *
                    <br>
                    <input type='text' name='nombre' required>
                    <br>
                    Teléfono *
                    <br>
                    <input type='phone' name='telefono' >
                    <br>
                    Nick *
                    <br>
                    <input type='text' name='nick' required>
                    <br>
                    Contraseña *
                    <br>
                    <input type='password' name='contraseña' required>
                    <br>
                    <input id='boton_noticia' type='submit' name=enviar>
                </div>
            </form>     
        </div>
        <!-- PHP SELECIONAR IMAGENES -->
        <?php
            if(isset($_POST["enviar"])){
                $dni=$_POST['dni'];
                $nombre=$_POST['nombre'];
                $telefono=$_POST['telefono'];
                $nick=$_POST['nick'];
                $contraseña=$_POST['contraseña'];
                

                $con=conexionVete();

                $sentencia = "insert into dueño
                                values ('$dni', '$nombre', '$telefono', '$nick', '$contraseña')";

                $datos = $con->query($sentencia);

                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                    echo "datos insertados correctamente";
                }
                $con->close();
                echo "<meta http-equiv='refresh' content='0;url=../html/dueños.php'>";
            }
        ?>

    </main>

    <footer>
        <!-- FUNCION FOOTER -->
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>