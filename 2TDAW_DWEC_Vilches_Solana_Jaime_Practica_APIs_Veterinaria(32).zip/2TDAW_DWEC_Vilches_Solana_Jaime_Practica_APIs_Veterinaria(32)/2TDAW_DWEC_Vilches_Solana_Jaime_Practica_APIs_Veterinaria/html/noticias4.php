<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
    
    <header>
        <?php
            require_once("../php/funciones.php");
            menu();
        ?>
    </header>

    <main>
    <div id="fondo_noticias">
            <h1>NOTICIAS</h1>
            <hr id="hr1">
            <?php
            	//1. conectarme con la base de datos
            	$con = new mysqli("localhost","root","","veterinaria");
            	$con->set_charset("utf8");

            	//2. crear la consulta
            	$sentencia = "Select *
							from noticia
                            limit 0,4";

         		//3. ejecutar la sentencia
            	$datos = $con->query($sentencia);

            	//4. comprobar errores
            	if(!$datos){
                	echo "error en la sentencia $con->error";
            	}else{
                //5. comprobar si hay datos
                if($datos->num_rows<=0){
                    echo "no hay noticias para mostrar";
                }else{
                //6. trabajar con los datos
                while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
                    echo 
						"<div class='fondo_noticias'>
                        <div class='noticiario'>
                            <h2>$fila[Titulo]</h2>
                            <p>$fila[Contenido]</p>
                            <img style='width: 40%;' src='$fila[Imagen]'>
                            <p>$fila[Fecha_publicacion]</p>
                            <hr>
                        </div>
                    </div>";
                    }
                }
            }
            $con->close();
        	?>
        <div id="botones">
            <a id="boton_pg" href="../html/noticias.php" ><input id="pg" type="submit" value="<<"></a>
            <a id="boton_pg" href="../html/noticias2.php" ><input id="pg" type="submit" value="2"></a>
            <a id="boton_pg" href="../html/noticias3.php" ><input id="pg" type="submit" value="3"></a>
            <a id="boton_pg" href="../html/noticia4.php" ><input id="actual" type="submit" value="4"></a>
        </div>
    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>