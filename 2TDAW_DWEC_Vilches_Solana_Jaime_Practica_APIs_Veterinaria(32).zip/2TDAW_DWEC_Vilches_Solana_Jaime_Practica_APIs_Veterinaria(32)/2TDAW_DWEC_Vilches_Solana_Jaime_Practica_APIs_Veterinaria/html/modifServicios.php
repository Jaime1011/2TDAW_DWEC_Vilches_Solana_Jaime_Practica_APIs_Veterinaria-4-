<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>

        <?php
            $mostrarId='select AUTO_INCREMENT from information_schema.TABLES where TABLE_SCHEMA="veterinaria" and TABLE_NAME="servicio"';
            $con=conexionVete();

            $muestra = $con->query($mostrarId);

            if($muestra == true){
                $datos=$con->query($mostrarId);
                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                    if($datos->num_rows<=0){
                        echo "No se ha encontrado una Id";
                    }else{
                        while($fila = $datos->fetch_row()){
                            $IdServicio = $fila[0];
                        }
                    }
                }
            }else{
                echo "Error en la busqueda de Id";
            }
        ?>
        
        <h1>MODIFICAR SERVICIOS</h1>
        <div class="fondo_insertProductos">
        <?php
            $con=conexionVete();
            $idServicio=$_POST['dato'];
            $consulta1="SELECT * FROM servicio WHERE ID='$idServicio'";
            $resultado=$con->query($consulta1);
            $fila=$resultado->fetch_array();
            if($resultado->num_rows>0){
                echo"<form action='#' method='post'>
                        <input type='text' name='id' value='$fila[ID]' placeholder=<?php echo $IdServicio? hidden>
                        <br><br>
                        <label for'descripcion'>Descripción:</label>
                        <input type='text' name='descripcion' value='$fila[Descripcion]'>
                        <br><br>
                        <label for'duracion'>Duración:</label>
                        <input type='text' name='duracion' value='$fila[Duración]'>
                        <br><br>
                        <label for'precio'>Precio:</label>
                        <input type='text' name='precio' value='$fila[Precio]'>
                        <br><br>
                        <input id='boton' type='submit' name='enviar'>
                        <input type='hidden' name='dato' value='$fila[ID]'>
                    </form>";
            }
            ?>
        </div>

        <?php
            if(isset($_POST["enviar"])){
                $descripcion=$_POST['descripcion'];
                $duracion=$_POST['duracion'];
                $precio=$_POST['precio'];
                $ID=$_POST['id'];

                $con=conexionVete();

                $sentencia = "UPDATE servicio set Descripcion='$descripcion', Duración='$duracion', Precio='$precio'
                WHERE ID='$ID'";

                $resultado = $con->query($sentencia);

                if(!$resultado){
                    echo "error en la sentecia $con->error";
                }else{
                    echo "MODIFICADO CORERECTAMENTE";
                }

                $con->close();
                echo "<meta http-equiv='refresh' content='0;url=../html/servicios.php'>";
            }

        ?>

    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>