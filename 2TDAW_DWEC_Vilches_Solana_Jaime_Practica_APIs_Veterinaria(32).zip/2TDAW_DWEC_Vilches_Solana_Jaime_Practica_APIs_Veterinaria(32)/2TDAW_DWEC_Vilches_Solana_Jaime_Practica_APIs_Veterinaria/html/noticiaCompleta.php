<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../styles/styles.css">
    <script type="text/javascript" src="../js/app.js" defer></script>

    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        <div id="fondo_noticias">
            <h1>NOTICIA COMPLETA</h1>
            <hr id="hr1">
            <?php
                $mostrarId='select AUTO_INCREMENT from information_schema.TABLES where TABLE_SCHEMA="veterinaria" and TABLE_NAME="noticia"';
                $con=conexionVete();

                $muestra = $con->query($mostrarId);

                if($muestra == true){
                    $datos=$con->query($mostrarId);
                    if(!$datos){
                        echo "error en la sentencia $con->error";
                    }else{
                        if($datos->num_rows<=0){
                            echo "No se ha encontrado una Id";
                        }else{
                            while($fila = $datos->fetch_row()){
                                $IdNoticia = $fila[0];
                            }
                        }
                    }
                }else{
                    echo "Error en la busqueda de Id";
                }
            ?>
            <?php
                $con=conexionVete();
                $idNoticia=$_POST['dato'];
                $consulta1="SELECT * FROM noticia WHERE ID='$idNoticia'";
                $resultado=$con->query($consulta1);
                $fila=$resultado->fetch_array();
                if($resultado->num_rows>0){
                    echo 
                        "<div class='fondo_noticias'>
                            <div class='noticiario'>
                                <h2>$fila[titulo]</h2>
                                <p>$fila[contenido]</p>
                                <img style='width: 40%;' src='$fila[imagen]'>
                                <p>$fila[fecha_publicacion]</p>
                                <hr>
                            </div>
                        </div>";
                    }
                $con->close();
        	?>
            	
        </div>
    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>