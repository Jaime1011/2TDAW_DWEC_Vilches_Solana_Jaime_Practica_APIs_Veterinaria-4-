<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>

        <?php
            $mostrarId='select AUTO_INCREMENT from information_schema.TABLES where TABLE_SCHEMA="veterinaria" and TABLE_NAME="producto"';
            $con=conexionVete();

            $muestra = $con->query($mostrarId);

            if($muestra == true){
                $datos=$con->query($mostrarId);
                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                    if($datos->num_rows<=0){
                        echo "No se ha encontrado una Id";
                    }else{
                        while($fila = $datos->fetch_row()){
                            $IdProducto = $fila[0];
                        }
                    }
                }
            }else{
                echo "Error en la busqueda de Id";
            }
        ?>

        <h1>INSERTAR PRODUCTOS</h1>
        <div class="fondo_insertProductos">
            <form>
                <div id='primero'>
                    Id:
                    <br>
                    <input type='text' name='a' disabled placeholder=<?php echo $IdProducto?>>
                    <br>
                    Nombre *
                    <br>
                    <input type='text' name='n' required>
                    <br>
                    Precio *
                    <br>
                    <input type='nuber' name='p' required>
                </div>
                <br>
                <input id='boton' type='submit' name=enviar>
            </form>     
        </div>

        <?php
            if(isset($_GET["enviar"])){
                $nombre=$_GET['n'];
                $precio=$_GET['p'];

                $con=conexionVete();
                
                $sentencia = "insert into producto
                                values ('','$nombre', '$precio')";

                $datos = $con->query($sentencia);

                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                    echo "datos insertados correctamente";
                }
                $con->close();
            }
        ?>

    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>