<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
    <!-- BUSCADOR REQUEST -->
    <?php
        $busqueda=strtolower($_REQUEST['busqueda']);
    ?>
    
    <section id="productos">
			<div id="titulo_sec">
				<h1 id="titular">NUESTRO PRODUCTOS</h1>
				<?php
                    if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                        echo "<a id='boton_pg' href='../html/insertProductos.php'><input style='margin-left: 47.5%;' id='insertar' type='button' value='Insertar'></a>";
                    }
                ?>
                <form action='../html/buscarProductos.php' method='post'>
        		    <input id="buscador" type="text" name="busqueda" placeholder="Buscar..." aria-label="Search">
                    <input id='buscar' type='submit' name='enviar-buscar' value='Buscar'>
                </form>
                <hr>
			</div>
			<div id="contenedor_producto">
                <!-- PHP DEL BUSCADOR -->
                <?php
                    $con=conexionVete();

                    if(isset($_POST["enviar-buscar"])){
                        
                        $consulta = "SELECT * FROM producto WHERE Nombre LIKE '%$busqueda%' or Precio LIKE '%$busqueda%'";

                        $resultado = $con->query($consulta);

                        if(!$resultado){
                            echo "error en la sentencia $con->error";
                        }else{
                            if($resultado->num_rows<=0){
                                echo "no hay productos para mostrar";
                            }else{
                                while($fila = $resultado->fetch_array(MYSQLI_ASSOC)){
                                    echo 
                                        "<div id='columna_producto'>
                                            <h2>$fila[Nombre]</h2>
                                            <h3>Precio: $fila[Precio]€</h3>";

                                            if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                                                echo"<form action='../html/modifProductos.php' method='post'>
                                                        <input id='modificar' type='submit' value='Modificar'>
                                                        <input type='hidden' name='dato' value='$fila[ID]'>
                                                    </form>
                                                    
                                                    <form action='#' method='get'>
                                                        <input id='borrar' type='submit' name='borrar' value='Borrar'>
                                                        <input type='hidden' name='borrar_id' value='$fila[ID]'>
                                                    </form>";
                                            }
                                        echo "</div>";
                                    }
                        }
                    }
                }

                ?>
                
			</div>

		</section>
        


    </main>

    <footer>
        <!-- FUNCION FOOTER -->
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>
</body>
</html>