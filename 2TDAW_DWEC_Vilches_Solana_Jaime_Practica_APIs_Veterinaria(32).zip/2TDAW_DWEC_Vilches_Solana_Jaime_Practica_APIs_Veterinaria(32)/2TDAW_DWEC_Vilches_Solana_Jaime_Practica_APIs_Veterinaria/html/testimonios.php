<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"]) || $_SESSION["dni"]!=="000000000"){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>

<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        
        <div id="fondo_servicios">
        <h1>TESTIMONIOS</h1>
        <a id='boton_pg' href='../html/insertTestimonios.php' ><input style="margin-left: 47.5%;" id='insertar' type='button' value='Insertar'></a>
        <?php
                //1. conectarme con la base de datos
                $con=conexionVete();

                //2. crear la consulta
                $sentencia = "Select *
						    from testimonio
                            order by Fecha Desc";

                //3. ejecutar la sentencia
                $datos = $con->query($sentencia);

                //4. comprobar errores
                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                //5. comprobar si hay datos
                if($datos->num_rows<=0){
                    echo "No hay testimonios para mostrar";
                }else{
                //6. trabajar con los datos
                    while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
                        echo 
                        "<div id='servicio'>
                        <hr id='hr1'>
                            <h4><b>Autor:</b> $fila[dni_autor]</h4>
                            <h5>Fecha: $fila[fecha]</h5>
                            <p>$fila[contenido]</p>
                            <hr> 
                        </div>";
                    }
                }
            }
            $con->close();
        ?>
        </div>

    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>
</body>
</html>