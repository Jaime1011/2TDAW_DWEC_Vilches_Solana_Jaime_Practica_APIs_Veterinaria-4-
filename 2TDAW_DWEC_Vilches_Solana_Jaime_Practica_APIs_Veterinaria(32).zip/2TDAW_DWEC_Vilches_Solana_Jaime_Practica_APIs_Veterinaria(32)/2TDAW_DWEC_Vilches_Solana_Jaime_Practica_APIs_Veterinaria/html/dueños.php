<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
        if($_SESSION["dni"]==="000000000"){
            echo "<title>Dueños</title>";
        }else{
            echo "<title>Mis datos</title>";
        }
    ?>
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
    
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        
        <div id="fondo_noticias">
        <h1>DUEÑOS</h1>
        <?php
            if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                echo "<a id='boton_pg' href='../html/insertDueños.php'><input style='margin-left: 47.5%;' id='insertar' type='button' value='Insertar'></a>";
            }
        ?>
        <form action='../html/buscarDueños.php' method='post' id='buscador'>
        	<input id="buscador" type="text" name="busqueda" placeholder="Buscar..." aria-label="Search">
            <input id='buscar' type='submit' name='enviar-buscar' value='Buscar'>
        </form>
        
        <!-- PHP muestra clientes -->
        <?php
                //1. conectarme con la base de datos
                $con=conexionVete();

                //2. crear la consulta
                $sentencia = "Select *
						    from dueño";

                //3. ejecutar la sentencia
                $datos = $con->query($sentencia);

                //4. comprobar errores
                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                //5. comprobar si hay datos
                if($datos->num_rows<=0){
                    echo "No hay dueños para mostrar";
                }else{
                //6. trabajar con los datos
                    while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
                        echo 
                        "<div class='cliente'>
                            <hr id='hr1'>
                            <h2>Dni: $fila[dni]</h2>
                            <h3>Nombre: $fila[nombre]</h3>
                            <p>Telefono: $fila[telefono]</p>
                            <p>Nick: $fila[nick]</p>
                            <form action='../html/modifDueños.php' method='post'>
                                <input id='modificar' type='submit' value='Modificar'>
                                <input type='hidden' name='dato' value='$fila[dni]'>
                            </form>
                            <hr> 
                        </div>";
                    }
                }
            }
            $con->close();
            ?>
        </div>

    </main>

    <footer>
        <!-- FUNCION FOOTER -->
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>