<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>

<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>

    <?php
        $mostrarId='select AUTO_INCREMENT from information_schema.TABLES where TABLE_SCHEMA="veterinaria" and TABLE_NAME="noticia"';
        $con=conexionVete();

        $muestra = $con->query($mostrarId);

        if($muestra == true){
            $datos=$con->query($mostrarId);
            if(!$datos){
                echo "error en la sentencia $con->error";
            }else{
                if($datos->num_rows<=0){
                    echo "No se ha encontrado una Id";
                }else{
                    while($fila = $datos->fetch_row()){
                        $IdNoticia = $fila[0];
                    }
                }
            }
        }else{
            echo "Error en la busqueda de Id";
        }
    ?>
        
        <h1>INSERTAR NOTICIAS</h1>
        <div class="fondo_insertNoticias">
            <form action="#" method="post" enctype="multipart/form-data">
                <div id='primero'>
                    Id:
                    <br>
                    <input type='text' name='id' disabled placeholder=<?php echo $IdNoticia?>>
                    <br>
                    Titulo *
                    <br>
                    <input type='text' name='titulo' required>
                    <br>
                    Contenido *
                    <br>
                    <input type='text' name='contenido' required>
                    <br>
                    Imagen *
                    <br>
                    <input type='text' name='imagen' required>
                    <br>
                    Fecha *
                    <br>
                    <input type='date' name='fecha' required>
                    <br>
                    <br>
                    <input id='boton_noticia' type='submit' name=enviar>
                </div>
            </form>     
        </div>

        <?php
            if(isset($_POST["enviar"])){

                // $con=conexionVete();

                // $imagen_noticia=$_FILES['imagen']['name'];
                // $temp=$_FILES['imagen']['tmp_name'];

                // if(!file_exists("../assetsNoticias/")){
                //     mkdir("../assetsNoticias/");
                // }

                // if($_FILES['imagen']['type']==="image/png"){
                //     $imagen_noticia=$imagen_noticia.".png";
                // }elseif($_FILES['imagen']['type']==="image/jpg"){
                //     $imagen_noticia=$imagen_noticia.".jpg";
                // }

                // $ruta1="../assets/$imagen_noticia";
                // $ruta2="assets/$imagen_noticia";

                // move_uploaded_file($temp,$ruta1);
                
                $titulo=$_POST['titulo'];
                $contenido=$_POST['contenido'];
                $imagen=$_POST['imagen'];
                $fecha=$_POST['fecha'];

                $sentencia = "insert into noticia
                                values ('','$titulo', '$contenido', '$imagen', '$fecha')";

                $datos = $con->query($sentencia);

                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                    echo "datos insertados correctamente";
                }
                $con->close();
            }
        ?>

    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>

</body>
</html>