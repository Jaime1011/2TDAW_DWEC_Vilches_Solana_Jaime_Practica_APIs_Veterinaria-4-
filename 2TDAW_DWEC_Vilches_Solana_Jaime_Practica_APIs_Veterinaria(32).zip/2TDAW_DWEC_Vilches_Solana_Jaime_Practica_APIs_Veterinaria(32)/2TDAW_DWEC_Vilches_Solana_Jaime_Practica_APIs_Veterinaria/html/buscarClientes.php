<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
        if($_SESSION["dni"]==="000000000"){
            echo "<title>Clientes</title>";
        }else{
            echo "<title>Mis mascotas</title>";
        }
    ?>
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>


<main>
        <!-- BUSCADOR REQUEST -->
    <?php
        $busqueda=strtolower($_REQUEST['busqueda']);
    ?>
    
    <div id="fondo_noticias">
        <h1>CLIENTES</h1>
        <a id='boton_pg' href='../html/insertClientes.php' ><input style="margin-left: 47.5%;" id='insertar' type='button' value='Insertar'></a>
        <form action='../html/buscarClientes.php' method='post'>
        	<input id="buscador" type="text" name="busqueda" placeholder="Buscar..." aria-label="Search">
            <input id='buscar' type='submit' name='enviar-buscar' value='Buscar'>
        </form>

        <!-- PHP DEL BUSCADOR -->
        <?php
            $con=conexionVete();

            if(isset($_POST["enviar-buscar"])){
                
                $consulta = "SELECT id,cliente.nombre nom_cli,tipo,edad,foto,dueño.nombre nom_due FROM cliente WHERE nom_cli LIKE '%$busqueda%' or nom_due LIKE '%$busqueda%' or telefono LIKE '%$busqueda%'";

                $resultado = $con->query($consulta);

                if(!$resultado){
                    echo "error en la sentencia $con->error";
                }else{
                    if($resultado->num_rows<=0){
                        echo "no hay clientes para mostrar";
                    }else{
                        while($fila = $resultado->fetch_array(MYSQLI_ASSOC)){
                            echo 
                        "<div class='cliente'>
                            <hr id='hr1'>
                            <img src='../$fila[Foto]' style='width: 25%;'>
                            <h2>$fila[Nombre]</h2>
                            <h3>Edad: $fila[Edad] años</h3>
                            <p>Nombre dueño: $fila[Nombre_dueño]</p>
                            <p>Telefono: $fila[Telefono]</p>
                            <form action='../html/modifClientes.php' method='post'>
                                <input id='modificar' type='submit' value='Modificar'>
                                <input type='hidden' name='dato' value='$fila[ID]'>
                            </form>
                            <hr> 
                        </div>";
                    }
                }
            }
        }
            $con->close();
        ?>
        </div>

    </main>

    <footer>
        <!-- FUNCION FOOTER -->
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>
</body>
</html>