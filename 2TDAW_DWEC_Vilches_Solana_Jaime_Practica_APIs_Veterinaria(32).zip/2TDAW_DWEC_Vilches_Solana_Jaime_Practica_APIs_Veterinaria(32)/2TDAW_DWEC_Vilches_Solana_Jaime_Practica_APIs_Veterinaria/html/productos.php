<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
<!-- CONEXION BASE DE DATOS -->
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        
        <section id="productos">
			<div id="titulo_sec">
				<h1 id="titular">NUESTRO PRODUCTOS</h1>
                <!-- BOTÓN INSERTAR -->
                <?php
                if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                    echo "<a id='boton_pg' href='../html/insertProductos.php'><input style='margin-left: 47.5%;' id='insertar' type='button' value='Insertar'></a>";
                }
            ?>
                <!-- BUSCADOR -->
                <form action='../html/buscarProductos.php' method='post'>
        		    <input id="buscador" type="text" name="busqueda" placeholder="Buscar..." aria-label="Search">
                    <input id='buscar' type='submit' name='enviar-buscar' value='Buscar'>
                </form>
                <hr>
			</div>

			<div id="contenedor_producto">
            <?php
                if(isset($_GET["borrar"])){
                    $con=conexionVete();
                    
                    $borrarID=$_GET['borrar_id'];

                    $consulta = "DELETE FROM producto WHERE ID='$borrarID'";

                    $resultado = $con->query($consulta);

                    if(!$resultado){
                        echo "error en la sentencia $con->error";
                    }

                    $con->close();
                }
            ?>

                <?php
                    //1. conectarme con la base de datos
                    $con=conexionVete();

                    //2. crear la consulta
                    $sentencia = "Select *
                                from producto";

                    //3. ejecutar la sentencia
                    $datos = $con->query($sentencia);

                    //4. comprobar errores
                    if(!$datos){
                        echo "error en la sentencia $con->error";
                    }else{
                    //5. comprobar si hay datos
                    if($datos->num_rows<=0){
                        echo "no hay productos para mostrar";
                    }else{
                    //6. trabajar con los datos
                    while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
                        echo 
                            "<div id='columna_producto'>
                                <h2>$fila[nombre]</h2>
                                <h3>Precio: $fila[precio]€</h3>";

                                if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                                    echo"<form action='../html/modifProductos.php' method='post'>
                                            <input id='modificar' type='submit' value='Modificar'>
                                            <input type='hidden' name='dato' value='$fila[id]'>
                                        </form>
                                        
                                        <form action='#' method='get'>
                                            <input id='borrar' type='submit' name='borrar' value='Borrar'>
                                            <input type='hidden' name='borrar_id' value='$fila[id]'>
                                        </form>";
                                }
                                
                        echo "</div>";
                        }
                    }
                }
                $con->close();
                ?>
			</div>

            
		</section>

    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>
</body>
</html>