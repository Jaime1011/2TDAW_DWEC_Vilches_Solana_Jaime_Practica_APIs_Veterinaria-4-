<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(!isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>
<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
    <!-- BUSCADOR REQUEST -->
    <?php
        $busqueda=strtolower($_REQUEST['busqueda']);
    ?>
    
    <div id="fondo_servicios">
        <h1>SERVICIOS</h1>
        <?php
            if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                echo "<a id='insertar' href='../html/insertServicios.php'>Insertar</a>";
            }
        ?>
        <form action='../html/buscarServicios.php' method='post'>
        	<input id="buscador" type="text" name="busqueda" placeholder="Buscar..." aria-label="Search">
            <input id='buscar' type='submit' name='enviar-buscar' value='Buscar'>
        </form>
        <!-- PHP DEL BUSCADOR -->
        <?php
            $con=conexionVete();

            if(isset($_POST["enviar-buscar"])){
                
                $consulta = "SELECT * FROM servicio WHERE Descripcion LIKE '%$busqueda%'";

                $resultado = $con->query($consulta);

                if(!$resultado){
                    echo "error en la sentencia $con->error";
                }else{
                    if($resultado->num_rows<=0){
                        echo "no hay servicios para mostrar";
                    }else{
                        while($fila = $resultado->fetch_array(MYSQLI_ASSOC)){
                            echo 
                        "<div id='servicio'>
                        <hr id='hr1'>
                            <p><b>Descripcion:</b> $fila[Descripcion]</p>
                            <h4>Duración: $fila[Duración]min</h4>
                            <h4>Precio: $fila[Precio]€</h4>";

                            if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                                echo"<form action='../html/modifServicios.php' method='post'>
                                        <input id='modificar' type='submit' value='Modificar'>
                                        <input type='hidden' name='dato' value='$fila[ID]'>
                                    </form>";
                            }
                            echo "<hr> 
                            </div>";
                    }
                }
            }
        }
            $con->close();
        ?>
        </div>
                
			</div>

		</section>
        
    </main>

    <footer>
        <!-- FUNCION FOOTER -->
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>
</body>
</html>