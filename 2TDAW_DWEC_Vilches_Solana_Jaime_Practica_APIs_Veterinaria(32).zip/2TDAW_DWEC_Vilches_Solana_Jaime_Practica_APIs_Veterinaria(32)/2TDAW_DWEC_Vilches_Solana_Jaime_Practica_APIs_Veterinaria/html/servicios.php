<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: ../index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body>

<?php
    require_once("../php/funciones.php");
    $con=conexionVete();
?>
    
    <header>
        <!-- FUNCION MENU -->
        <?php
            menu('../');
        ?>
    </header>

    <main>
        
        <div id="fondo_servicios">
        <h1>SERVICIOS</h1>
        <!-- BOTON INSERTAR -->
        <?php
            if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                echo "<a id='boton_pg' href='../html/insertServicios.php'><input style='margin-left: 47.5%;' id='insertar' type='button' value='Insertar'></a>";
            }
        ?>
        <!-- BUSCADOR -->
        <form action='../html/buscarServicios.php' method='post'>
        	<input id="buscador" type="text" name="busqueda" placeholder="Buscar..." aria-label="Search">
            <input id='buscar' type='submit' name='enviar-buscar' value='Buscar'>
        </form>
        <?php
                //1. conectarme con la base de datos
                $con=conexionVete();

                //2. crear la consulta
                $sentencia = "Select *
						    from servicio";

                //3. ejecutar la sentencia
                $datos = $con->query($sentencia);

                //4. comprobar errores
                if(!$datos){
                    echo "error en la sentencia $con->error";
                }else{
                //5. comprobar si hay datos
                if($datos->num_rows<=0){
                    echo "No hay servicios para mostrar";
                }else{
                //6. trabajar con los datos
                    while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
                        echo 
                        "<div id='servicio'>
                        <hr id='hr1'>
                            <p><b>Descripcion:</b> $fila[descripcion]</p>
                            <h4>Duración: $fila[duracion]min</h4>
                            <h4>Precio: $fila[precio]€</h4>";

                            if(isset($_SESSION["dni"]) && $_SESSION["dni"]==="000000000"){
                                echo"<form action='../html/modifServicios.php' method='post'>
                                        <input id='modificar' type='submit' value='Modificar'>
                                        <input type='hidden' name='dato' value='$fila[ID]'>
                                    </form>";
                            }
                        echo "<hr> 
                        </div>";
                    }
                }
            }
            $con->close();
        ?>
        </div>

    </main>

    <footer>
        <?php
            require_once("../php/funciones.php");
            footer();
        ?>
    </footer>
</body>
</html>