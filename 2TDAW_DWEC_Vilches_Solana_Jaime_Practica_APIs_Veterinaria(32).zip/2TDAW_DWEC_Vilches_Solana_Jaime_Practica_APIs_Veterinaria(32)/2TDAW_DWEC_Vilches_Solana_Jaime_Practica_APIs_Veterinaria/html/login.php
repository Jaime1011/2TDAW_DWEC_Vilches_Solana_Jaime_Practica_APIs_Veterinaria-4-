<?php
    session_start();

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }

    if(isset($_SESSION["dni"])){
        header('Location: ../index.php');
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/styles.css">
    <title>Document</title>
</head>
<body class="body_login">
        <?php
            require_once("../php/funciones.php");
            $con=conexionVete();
        ?>

    <main>
        <div class="tarjeta_login">
            <div id="logo_solo">
                <a class="no-bar" href="../index.php"><img id="logo_solo" src="../assets/logo.png" style="width: 20%;"></a>  
            </div>
            <h1 id="inicio">INICIO DE SESIÓN</h1>
            <form action='#' method='post'  enctype='multipart/form-data' class="form_login">
                <input id='usuario' type='text' name='nick' placeholder='Nombre de usuario'>
                <br>
                <input id='password' type='password' name='pass' placeholder='Contraseña'>
                <br>
                <input id='checkbox' type='checkbox' name='mantener' value='mantener'>Mantener sesión iniciada</input>
                <input id='logearse' type='submit' name='enviar'>
            </form>
        </div>
        

        <?php
            if(isset($_POST["enviar"])){
                $nick=trim($_POST["nick"]);
                $pass=md5(md5(md5(md5(md5(md5(md5(trim($_POST['pass']))))))));
                

                $consulta="SELECT dni FROM dueño WHERE nick=? and pass=?";
                $resultado=$con->prepare($consulta);
                $resultado->bind_param("ss",$nick, $pass);
                $resultado->bind_result($dni);
                $resultado->execute();
                $resultado->store_result();
                
                $devuelve=$resultado->num_rows;  

                if($devuelve===0){
                    echo "<h3>Nick o contraseña incorrectos</h3>";         
                }else{     
                    $resultado->fetch();

                    if(isset($_POST["mantener"])){
                        setcookie("mantener",$dni,time()+60*60*24*365,"/");
                    }else{
                        $_SESSION["dni"]=$dni;
                    }
            
                    echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
                }

                $resultado->close();
            }
        ?>

    <?php
        $con->close();
    ?>

    </main>

    <footer>

    </footer>
</body>
</html>