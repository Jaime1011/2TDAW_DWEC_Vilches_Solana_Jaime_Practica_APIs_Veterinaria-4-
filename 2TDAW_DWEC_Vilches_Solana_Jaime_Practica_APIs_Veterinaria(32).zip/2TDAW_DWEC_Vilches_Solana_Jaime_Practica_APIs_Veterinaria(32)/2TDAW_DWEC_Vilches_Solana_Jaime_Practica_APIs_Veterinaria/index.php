<?php
    session_start();

    if(isset($_GET["cerrar_sesion"])){
        setcookie("mantener",null,time()-60,"/");
        $_SESSION=array();
        session_destroy();
        header('Location: index.php');
    }

    if(isset($_COOKIE["mantener"])){
        $_SESSION["dni"]=$_COOKIE["mantener"];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" href="styles/styles.css">
	<script type="text/javascript" src="js/app.js" defer></script>
	<link rel="icon" href="../Vilches_Solana_Jaime (1)/assets/logo.png" type="image/x-icon">
    <title>Clínica veterinaria</title>
</head>
<body>
		<?php
            require_once("./php/funciones.php");
            $con=conexionVete();
        ?>
    <header>
		<!-- FUNCION MENU -->
		<?php
			menu('.');
		?>
    </header>

	<div id="fondo" style="height: 700px; border-bottom: solid 3px #a0ce26;">

	</div>

    <main>
		<section id="noticias">
			<div id="titulo_sec">
				<h1 id="titular">ÚLTIMAS NOTICIAS</h1>
				<hr>
			</div>
			<div id="contenedor">
			<?php
            	//1. conectarme con la base de datos
            	$con=conexionVete();

            	//2. crear la consulta
            	$sentencia = "Select *
							from noticia
							order by fecha_publicacion desc
							limit 0,3";

         		//3. ejecutar la sentencia
            	$datos = $con->query($sentencia);

            	//4. comprobar errores
            	if(!$datos){
                	echo "error en la sentencia $con->error";
            	}else{
                //5. comprobar si hay datos
                if($datos->num_rows<=0){
                    echo "no hay noticias para mostrar";
                }else{
                //6. trabajar con los datos
                while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
					$suspensivos = substr($fila['contenido'], 0, 150);
					$suspensivos.= "...";
                    echo 
						"<div id='columna'>
							<h2>$fila[titulo]</h2>
							<img src='$fila[imagen]' style='width: 80%; margin-left: 10%;'>
							<p>$suspensivos</p>
							<form action='./html/noticiaCompleta.php' method='post'>
                                    <input id='completa' type='submit' value='Ver completa'>
                                    <input type='hidden' name='dato' value='$fila[id]'>
                            </form>

						</div>";
                    }
                }
            }
            $con->close();
        	?>
			</div>
		</section>
		
		<!-- GALERÍA -->
		<section id="galeria" class="container">
			<div class="row">
				<div class="col-12 bg-blue">
					<h2>Galería</h2>
				</div>
			</div>
				<div id="fotos" class="row">
			</div>
		</section>

		<section id="testimonios">
			<div id="titulo_sec">
				<h1 id="titular">TESTIMONIOS</h1>
				<hr>
			</div>
			<div id="contenedor">
			<?php
            	//1. conectarme con la base de datos
            	$con=conexionVete();

            	//2. crear la consulta
            	$sentencia = "Select *
							from testimonio
							order by rand()
							limit 0,1";

         		//3. ejecutar la sentencia
            	$datos = $con->query($sentencia);

            	//4. comprobar errores
            	if(!$datos){
                	echo "error en la sentencia $con->error";
            	}else{
                //5. comprobar si hay datos
                if($datos->num_rows<=0){
                    echo "no hay testimonios para mostrar";
                }else{
                //6. trabajar con los datos
                while($fila = $datos->fetch_array(MYSQLI_ASSOC)){
                    echo 
						"<div id='columna'>
							<h2>$fila[dni_autor]</h2>
							<p>$fila[contenido]</p>
						</div>";
                    }
                }
            }
            $con->close();
        	?>
			</div>
		</section>

		<section id="contacto">
			<div id="titulo_sec">
				<h1 id="titular">CONTACTO</h1>
				<hr>
			</div>
				<form>
					<div id="primero">
						Nombre *
						<br>
						<input type="text" name="n" required>
						<br>
						Apellidos *
						<br>
						<input type="text" name="a" required>
					</div>
					<div id="segundo">
						Correo electrónico *
						<br>
						<input type="email" name="c" required>
						<br>
						Teléfono *
						<br>
						<input type="tel" name="t" required>
					</div>
					<div id="tercero">
						Codigo postal 
						<br>
						<input type="number" name="cp">
						<br>
						Asunto *
						<br>
						<input type="text" name="as" required>
					</div>
					<div id="cuarto">
						<br>
						Cargar archivo
						<br>
						<input type="file" name="f" required>
					</div>
					<div id="quinto">
						<br>
						Mensaje *
						<br>
						<textarea cols="61" rows="20" required></textarea>
					</div>
					<br>
					<input id="boton" type="submit" name="enviar">
				</form>
		</section>
    </main>

    <footer>
		<!-- FUNCION FOOTER -->
		<?php
			require_once("php/funciones.php");
			footerIndex();
		?>
    </footer>
</body>
</html>