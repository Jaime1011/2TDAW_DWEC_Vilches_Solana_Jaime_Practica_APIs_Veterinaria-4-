<?php
    function conexionVete(){
        $conexionVeterinaria= new mysqli("localhost","root","","veterinaria");
        $conexionVeterinaria->set_charset("utf8");

        return $conexionVeterinaria;
    }

    // function menuIndex(){
    //     echo '<nav> 
    //     <div id="logo">
    //         <a class="no-bar" href="../Vilches_Solana_Jaime (1)/index.php"><img id="logo" src="../Vilches_Solana_Jaime (1)/assets/logo.png" style="width: 20%;"></a>  
    //     </div>
    //     <div id="apartados">
    //         <a href="../Vilches_Solana_Jaime (1)/index.php"><b>Inicio</b></a>
    //         <a href="../Vilches_Solana_Jaime (1)/html/clientes.php"><b>Clientes</b></a>
    //         <a href="../Vilches_Solana_Jaime (1)/html/productos.php"><b>Productos</b></a>
    //         <a href="../Vilches_Solana_Jaime (1)/html/servicios.php"><b>Servicios</b></a>
    //         <a href="../Vilches_Solana_Jaime (1)/html/testimonios.php"><b>Testimonios</b></a>
    //         <a href="../Vilches_Solana_Jaime (1)/html/noticias.php"><b>Noticias</b></a>
    //         <a href="../Vilches_Solana_Jaime (1)/html/citas.php"><b>Citas</b></a>
    //         <a id="menu_dueños" href="../Vilches_Solana_Jaime (1)/html/dueños.php"><b>Dueños</b></a>
    //         <a id="login" href="../Vilches_Solana_Jaime (1)/html/login.php"><b>Iniciar sesión</b></a>
    //     </div>
    // </nav>';
    // }

    function menu($ruta){
        echo "<nav> 
        <div id='logo'>
            <a class='no-bar' href='$ruta/index.php'><img id='logo' src='$ruta/assets/logo.png' style='width: 20%;'></a>  
        </div>
        <div id='apartados'>
            <a href='$ruta/index.php'><b>Inicio</b></a>";

            if(isset($_SESSION['dni']) && $_SESSION['dni']==="000000000"){ 
                echo "<a href='$ruta/html/clientes.php'><b>Clientes</b></a>
                <a id='menu_dueños' href='$ruta/html/dueños.php'><b>Dueños</b></a>
                <a href='$ruta/html/noticias.php'><b>Noticias</b></a>
                <a href='$ruta/html/testimonios.php'><b>Testimonios</b></a>
                <a href='$ruta/html/citas.php'><b>Citas</b></a>";

            }else if(isset($_SESSION['dni']) && $_SESSION['dni']!=="000000000"){
                echo "<a href='$ruta/html/clientes.php'><b>Mis mascotas</b></a>
                <a id='menu_dueños' href='$ruta/html/dueños.php'><b>Mis datos personales</b></a>
                <a href='$ruta/html/citas.php'><b>Mis citas</b></a>";
            }

            echo "<a href='$ruta/html/servicios.php'><b>Servicios</b></a>
            <a href='$ruta/html/productos.php'><b>Productos</b></a>";

            if(isset($_SESSION['dni'])){
                echo"<a href='$ruta/index.php?cerrar_sesion'><b>Cerrar sesión</b></a>";
            }else{
                echo"<a  id='login' href='$ruta/html/login.php'><b>Iniciar sesión</b></a>";
            }
            echo '</div>
            </nav>';
        
    }

    function footerIndex(){
        echo '<h1>SIGENOS EN NUESTRAS REDES SOCIALES</h1>
		<div class="redes">
			<a id="ared"><img id="sm" src=".//assets/instagram.png"></a>
			<a id="ared"><img id="sm" src=".//assets/gorjeo.png"></a>
			<a id="ared"><img id="sm" src=".//assets/youtube.png"></a>
			<a id="ared"><img id="sm" src=".//assets/pinterest.png"></a>
		</div>
		</div>';
    }

    function footer(){
        echo "<h1>SIGENOS EN NUESTRAS REDES SOCIALES</h1>
		<div class='redes'>
			<a id='ared'><img id='sm' src='../assets/instagram.png'></a>
			<a id='ared'><img id='sm' src='../assets/gorjeo.png'></a>
			<a id='ared'><img id='sm' src='../assets/youtube.png'></a>
			<a id='ared'><img id='sm' src='../assets/pinterest.png'></a>
		</div>
		</div>";
    }

    function noticiasPrincipal(){
        echo '    
        <div id="fondo_noticias">
        <h1>NOTICIAS</h1>
        <hr id="hr1">
        <h2>TITULAR 1</h2>
        <img style="width: 40%;" src="../assets/imveterinaria_clientes_seguro_mascotas_4552_09164211.webp">
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam repellat, ex nesciunt illo odio quasi. Aut, blanditiis sint. Vitae recusandae perspiciatis dolor magnam odit vero autem totam laudantium voluptatibus sit!</p>
        <hr>
        <h2>TITULAR 2</h2>
        <img style="width: 40%;" src="../assets/imveterinaria_colegio_oficial_veterinarios_4576_12142016.jpg">
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam repellat, ex nesciunt illo odio quasi. Aut, blanditiis sint. Vitae recusandae perspiciatis dolor magnam odit vero autem totam laudantium voluptatibus sit!</p>
        <hr>
        <h2>TITULAR 3</h2>
        <img style="width: 40%;" src="../assets/imveterinaria_diabetes_mascotas_claves_4577_12143135.jpg">
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam repellat, ex nesciunt illo odio quasi. Aut, blanditiis sint. Vitae recusandae perspiciatis dolor magnam odit vero autem totam laudantium voluptatibus sit!</p>
        <hr>
        <h2>TITULAR 4</h2>
        <img style="width: 40%;" src="../assets/imveterinaria_clientes_seguro_mascotas_4552_09164211.webp">
        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam repellat, ex nesciunt illo odio quasi. Aut, blanditiis sint. Vitae recusandae perspiciatis dolor magnam odit vero autem totam laudantium voluptatibus sit!</p>
        </div>';
    }
    
?>