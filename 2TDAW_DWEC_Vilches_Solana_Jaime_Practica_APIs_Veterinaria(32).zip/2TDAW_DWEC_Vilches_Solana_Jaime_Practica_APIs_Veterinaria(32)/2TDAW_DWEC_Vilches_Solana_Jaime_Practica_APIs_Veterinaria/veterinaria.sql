-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-02-2022 a las 09:00:48
-- Versión del servidor: 10.4.20-MariaDB
-- Versión de PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `veterinaria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas`
--

CREATE TABLE `citas` (
  `cliente` bigint(20) UNSIGNED NOT NULL,
  `servicio` bigint(20) UNSIGNED NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `citas`
--

INSERT INTO `citas` (`cliente`, `servicio`, `fecha`, `hora`) VALUES
(25, 1, '2022-02-01', '06:39:00'),
(26, 4, '2022-01-17', '01:56:00'),
(27, 3, '2022-01-25', '14:55:00'),
(27, 2, '2022-01-31', '13:55:00'),
(28, 1, '2022-01-26', '15:50:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `edad` tinyint(3) UNSIGNED NOT NULL,
  `foto` varchar(255) NOT NULL,
  `dni_dueño` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id`, `tipo`, `nombre`, `edad`, `foto`, `dni_dueño`) VALUES
(27, 'perro', 'Rex', 3, 'c2.jpg', '54345434H'),
(28, 'gato', 'Trebol', 2, 'c1.jpg', '77553663D');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dueño`
--

CREATE TABLE `dueño` (
  `dni` varchar(9) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `telefono` varchar(9) DEFAULT NULL,
  `nick` varchar(25) NOT NULL,
  `pass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `dueño`
--

INSERT INTO `dueño` (`dni`, `nombre`, `telefono`, `nick`, `pass`) VALUES
('000000000', 'Administrador', NULL, 'admin', '4c14a808735abb4b205d1c8cb54ec845'),
('54345434H', 'Rocio', '', 'rocio', '2d786354e4145a6872e4a864e257f652'),
('65453465L', 'Pablo', '', 'pablo', '8845f6e2db4ae7f3f8ee29ff10a5b841'),
('77553663D', 'Jaime', '640151507', 'jaime', 'fc6aff4a94fc7d6b5b9039d743bb9880');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticia`
--

CREATE TABLE `noticia` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `contenido` varchar(5000) NOT NULL,
  `imagen` varchar(50) NOT NULL,
  `fecha_publicacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `noticia`
--

INSERT INTO `noticia` (`id`, `titulo`, `contenido`, `imagen`, `fecha_publicacion`) VALUES
(5, 'La masacre del ‘Ajolotón’', 'En la imagen de seis sonrientes alcaldes de Morena subidos a una trajinera con ajolote en mano todo estaba mal. Al acto ellos lo llamaron Ajolotón, pero los biólogos lo revelaron como lo que es: una masacre de estos anfibios mexicanos en peligro de extinción. Los políticos sacaron a los animales de sus peceras de conservación, los colocaron sobre el pasto, los agarraron como peluches, se hicieron muchas fotos y después los aventaron al agua en una de las zonas más contaminadas de estos canales al sur de Ciudad de México. El investigador y veterinario de la UNAM Horacio Mena, que lleva 14 años estudiando a los ajolotes, calcula que no debieron sobrevivir más de tres horas. Para los morenistas, en cambio, el show ayudó a preservar la especie.', 'https://tvazteca.brightspotcdn.com/dims4/default/9', '2022-02-15'),
(6, 'El puente que las ardillas tardaron casi una década en cruzar', 'Esta es una historia con final feliz, cuyos protagonistas son sendas poblaciones de ardillas y martas, y un puente de metal que une un bosque y un parque en la ciudad holandesa de La Haya. Construido en 2012 sobre la carretera que separa ambos parajes para facilitar su búsqueda de alimento, los animales han tardado casi una década en cruzarlo de forma regular. Demasiado, según los críticos, pensando en el gasto público destinado a través del Ayuntamiento a la obra: cerca de 150.000 euros de fondos estatales para el medio ambiente. Un tiempo prudencial, dijo la guarda forestal, porque roedores y mustélidos debían acostumbrarse a la pasarela a su ritmo. Después de años vacía, en 2021 hubo cerca de 400 viajes de ida y vuelta de estas especies y puede hablarse por fin de éxito.', 'https://lahuertinadetoni.es/wp-content/uploads/201', '2022-02-16'),
(7, 'Los mejores empapadores para perros', 'Una gran alternativa y ayuda para que los cachorros comiencen a aprender a hacer sus necesidades en el sitio adecuado son los empapadores para perros, diseñados para adiestrar a los animales y para ofrecer una solución efectiva que garantice la limpieza en el hogar cuando los perros no pueden salir a la calle, como por ejemplo cuando son mayores o mientras se espera en los aeropuertos.', 'https://estaticos.muyinteresante.es/media/cache/11', '2022-02-21');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Precio` double(4,2) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`ID`, `Nombre`, `Precio`) VALUES
(1, 'Juguete', 5.00),
(2, 'Correa', 3.00),
(3, 'Comida', 23.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `Descripcion` varchar(500) NOT NULL,
  `Duración` int(4) UNSIGNED NOT NULL,
  `Precio` double(5,2) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`ID`, `Descripcion`, `Duración`, `Precio`) VALUES
(1, 'CIRUGIA CORAZÓN', 130, 21.00),
(2, 'BAÑO', 50, 25.00),
(3, 'ETOLOGÍA', 60, 50.00),
(4, 'Peluqueria', 40, 32.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `testimonio`
--

CREATE TABLE `testimonio` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `Autor` varchar(50) NOT NULL,
  `Dni_autor` varchar(9) NOT NULL,
  `Contenido` varchar(500) NOT NULL,
  `Fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `testimonio`
--

INSERT INTO `testimonio` (`ID`, `Autor`, `Dni_autor`, `Contenido`, `Fecha`) VALUES
(1, 'Luisa', '', 'Increible trato por parte del personal, sin duda no dejaré de llevar a mis mascotas a este centro veterinario', '2021-12-10'),
(2, 'Juan', '', 'Magníficos profesionales, se nota que están bien preparados para su trabajo', '2021-12-08'),
(3, 'Mario', '', 'Trato de calidad, mi mascota ha salido tranquila y han solucionado su problema con rapidez', '2021-12-04'),
(4, 'María', '', 'Los productos que vende este centro son de alta calidad sin duda y a precios muy asequibles', '2021-12-04'),
(5, 'Pablo', '', 'Siempre publican las noticias mas interesantes de la semana', '2021-11-30');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`cliente`,`fecha`,`hora`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `dueño_cliente` (`dni_dueño`);

--
-- Indices de la tabla `dueño`
--
ALTER TABLE `dueño`
  ADD PRIMARY KEY (`dni`),
  ADD UNIQUE KEY `dni` (`dni`),
  ADD UNIQUE KEY `nick` (`nick`);

--
-- Indices de la tabla `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ID` (`id`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indices de la tabla `testimonio`
--
ALTER TABLE `testimonio`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `noticia`
--
ALTER TABLE `noticia`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `servicio`
--
ALTER TABLE `servicio`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `testimonio`
--
ALTER TABLE `testimonio`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `dueño_cliente` FOREIGN KEY (`dni_dueño`) REFERENCES `dueño` (`dni`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
